# RootMC Vote Sites Opener (Windows)

Double-click **`open-vote-sites.bat`** to open every official RootMC listing vote page in **one new browser window** (Edge or Chrome preferred).

## What you get

| Site | Reward |
|------|--------|
| Minecraft-MP | 1–20 G in-game when confirmed |
| MinecraftServers.org | same |
| Minecraft Server List | same |
| Minecraft.Buzz | same |
| TopMinecraftServers | same |
| MineRank | same |
| MinecraftList.org | same |
| Planet Minecraft | same |

Gold pays from the **Server Reserve** after Votifier confirms the vote. In-game: `/vote`.

## How to use

1. Unzip this folder anywhere (Desktop is fine).
2. Double-click `open-vote-sites.bat`.
3. Complete each site’s captcha / vote form (use the same Minecraft name as in-game).
4. Wait for the in-game / Discord confirmation, then enjoy the Gold.

SmartScreen may warn on first run — choose **More info → Run anyway**. The script only launches your browser with public HTTPS vote URLs; it does not install software or request admin rights.

## Tips

- Most sites allow **one vote per day** (some use a rolling 24h timer).
- Voting also adds **governance vote points** (Council weight) — see [rootmc.net/wiki/constitution/#governance-voting](https://rootmc.net/wiki/constitution/#governance-voting).
- Prefer Edge/Chrome so all tabs open in a single new window. Other browsers fall back to opening each link individually.

## Links

- Play: `play.rootmc.net`
- Site vote section: [rootmc.net](https://rootmc.net/#vote-heading)
- Live map: [map.rootmc.net](https://map.rootmc.net)
- Discord: [discord.gg/rFFQYrNaqS](https://discord.gg/rFFQYrNaqS)

---

Official RootMC tool · Windows · matches in-game `/vote` links
