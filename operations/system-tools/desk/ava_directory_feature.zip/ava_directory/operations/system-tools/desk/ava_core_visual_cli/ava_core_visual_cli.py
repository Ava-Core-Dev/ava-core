#!/usr/bin/env python3
import os, shlex, subprocess, threading, tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path

APP_TITLE = "AVA Core — Operations Console"
SERVICE = "ava-core.service"
LOG = Path("/home/ava-core/Database/logs/ava-core.log")
SYSTEMD_LOG = Path("/home/ava-core/Database/logs/ava-core-systemd.log")
CRONO_ROOT = Path("/home/ava-core/operations/cronologicals")
ALWAYS_ON = CRONO_ROOT / "always-on"
DIR_FLAG = ALWAYS_ON / "directory.enabled"
DIR_FLAG_DISABLED = ALWAYS_ON / "directory.enabled.disabled"
EXCLUDED_DIRS = {"always-on", "__pycache__"}

BG="#0b0f14"; PANEL="#111820"; PANEL2="#0d131a"; FG="#d8e6f3"
DIM="#8192a3"; CYAN="#53d8ff"; GREEN="#57e389"; RED="#ff6b6b"; YELLOW="#f8d66d"
FONT=("DejaVu Sans Mono", 10); TITLE=("DejaVu Sans Mono", 13, "bold")


def run(cmd, timeout=8):
    try:
        p = subprocess.run(cmd, shell=True, text=True, stdout=subprocess.PIPE,
                           stderr=subprocess.STDOUT, timeout=timeout)
        return p.returncode, p.stdout.strip()
    except Exception as e:
        return 1, str(e)


def cron_jobs():
    """Recursively discover cron scripts. *.py is ON; *.py.disabled is OFF."""
    jobs = []
    if not CRONO_ROOT.exists():
        return jobs
    for path in CRONO_ROOT.rglob("*"):
        if not path.is_file() or any(part in EXCLUDED_DIRS for part in path.parts):
            continue
        name = path.name
        if name.endswith(".py"):
            enabled = True
            display = name
        elif name.endswith(".py.disabled"):
            enabled = False
            display = name[:-9]
        else:
            continue
        try:
            rel = path.relative_to(CRONO_ROOT)
        except ValueError:
            rel = path
        jobs.append({"path": path, "rel": str(rel), "display": display, "enabled": enabled})
    return sorted(jobs, key=lambda j: (str(j["rel"]).lower(), not j["enabled"]))


def toggle_job(path: Path):
    if path.name.endswith(".py.disabled"):
        target = path.with_name(path.name[:-9])
        enabled = True
    elif path.name.endswith(".py"):
        target = path.with_name(path.name + ".disabled")
        enabled = False
    else:
        raise ValueError("Not a toggleable cron script")
    if target.exists():
        raise FileExistsError(f"Target already exists: {target.name}")
    path.rename(target)
    return target, enabled


def audio_jobs():
    """Recursively discover MP3 files. *.mp3 is ON; *.mp3.disabled is OFF."""
    jobs = []
    if not CRONO_ROOT.exists():
        return jobs
    for path in CRONO_ROOT.rglob("*"):
        if not path.is_file() or any(part in EXCLUDED_DIRS for part in path.parts):
            continue
        name = path.name.lower()
        if name.endswith(".mp3"):
            enabled, display = True, path.name
        elif name.endswith(".mp3.disabled"):
            enabled, display = False, path.name[:-9]
        else:
            continue
        jobs.append({"path": path, "rel": str(path.relative_to(CRONO_ROOT)),
                     "display": display, "enabled": enabled})
    return sorted(jobs, key=lambda j: str(j["rel"]).lower())


def directory_is_enabled() -> bool:
    """Directory page is ON unless explicitly disabled via flag file."""
    if DIR_FLAG_DISABLED.exists():
        return False
    # Explicit enable file optional; default ON when neither flag exists
    if DIR_FLAG.exists():
        return True
    return not DIR_FLAG_DISABLED.exists()


def toggle_directory() -> bool:
    """Toggle public /directory page. Returns new enabled state."""
    ALWAYS_ON.mkdir(parents=True, exist_ok=True)
    if directory_is_enabled():
        # turn OFF
        if DIR_FLAG.exists():
            DIR_FLAG.unlink()
        DIR_FLAG_DISABLED.write_text("disabled\n", encoding="utf-8")
        return False
    # turn ON
    if DIR_FLAG_DISABLED.exists():
        DIR_FLAG_DISABLED.unlink()
    DIR_FLAG.write_text("enabled\n", encoding="utf-8")
    return True


def toggle_audio(path: Path):
    lower = path.name.lower()
    if lower.endswith(".mp3.disabled"):
        target, enabled = path.with_name(path.name[:-9]), True
    elif lower.endswith(".mp3"):
        target, enabled = path.with_name(path.name + ".disabled"), False
    else:
        raise ValueError("Not a toggleable MP3 file")
    if target.exists():
        raise FileExistsError(f"Target already exists: {target.name}")
    path.rename(target)
    return target, enabled


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("1280x820")
        self.minsize(1000, 680)
        self.configure(bg=BG)
        self.protocol("WM_DELETE_WINDOW", self.destroy)
        self.after_id = None
        self.audio_after_id = None
        self.make_ui()
        self.refresh()
        self.refresh_crons()
        self.refresh_audio()

    def make_ui(self):
        top = tk.Frame(self, bg=PANEL, padx=18, pady=12)
        top.pack(fill="x")
        tk.Label(top, text="AVA CORE", font=("DejaVu Sans Mono",22,"bold"), fg=CYAN, bg=PANEL).pack(side="left")
        self.status = tk.Label(top, text="● CHECKING", font=TITLE, fg=YELLOW, bg=PANEL)
        self.status.pack(side="right")

        info = tk.Frame(self, bg=BG, padx=14, pady=10)
        info.pack(fill="x")
        self.cards = {}
        for key, label in [("service","SYSTEMD SERVICE"),("watchdog","CLOUDFLARE WATCHDOG"),
                           ("broadcast","BROADCAST SERVER"),("cloudflared","CLOUDFLARED"),
                           ("port","PORT 8080"),("directory","/DIRECTORY")]:
            box = tk.Frame(info, bg=PANEL2, padx=12, pady=8, highlightthickness=1, highlightbackground="#23313d")
            box.pack(side="left", fill="x", expand=True, padx=3)
            tk.Label(box,text=label,font=("DejaVu Sans Mono",8,"bold"),fg=DIM,bg=PANEL2).pack(anchor="w")
            val=tk.Label(box,text="CHECKING",font=("DejaVu Sans Mono",10,"bold"),fg=YELLOW,bg=PANEL2)
            val.pack(anchor="w", pady=(5,0)); self.cards[key]=val

        buttons = tk.Frame(self, bg=BG, padx=14, pady=4)
        buttons.pack(fill="x")
        for text, action in [("▶ START","start"),("■ STOP","stop"),("↻ RESTART","restart")]:
            tk.Button(buttons,text=text,command=lambda a=action:self.do_action(a),bg="#17222d",fg=FG,
                      activebackground="#243443",activeforeground=FG,relief="flat",padx=14,pady=8,
                      font=("DejaVu Sans Mono",10,"bold")).pack(side="left",padx=(0,6))
        tk.Button(buttons,text="⟳ REFRESH",command=self.refresh,bg="#17222d",fg=CYAN,relief="flat",padx=14,pady=8).pack(side="right")

        self.pages = ttk.Notebook(self)
        self.pages.pack(fill="both", expand=True, padx=14, pady=8)
        ops_page = tk.Frame(self.pages, bg=BG)
        audio_page = tk.Frame(self.pages, bg=BG)
        self.pages.add(ops_page, text="  OPERATIONS  ")
        self.pages.add(audio_page, text="  AUDIO  ")

        main = tk.Frame(ops_page, bg=BG, padx=0, pady=0)
        main.pack(fill="both", expand=True)
        left = tk.Frame(main, bg=PANEL); left.pack(side="left", fill="both", expand=True, padx=(0,5))
        right = tk.Frame(main, bg=PANEL); right.pack(side="left", fill="both", expand=True, padx=(5,0))

        tk.Label(left,text="LIVE AVA-CORE LOG",font=TITLE,fg=CYAN,bg=PANEL,padx=10,pady=8).pack(anchor="w")
        self.logbox=tk.Text(left,bg="#070b0f",fg=FG,insertbackground=CYAN,relief="flat",font=("DejaVu Sans Mono",9),wrap="none",state="disabled")
        self.logbox.pack(fill="both",expand=True,padx=10,pady=(0,10))

        tk.Label(right,text="PROCESS / SYSTEM STATUS",font=TITLE,fg=CYAN,bg=PANEL,padx=10,pady=8).pack(anchor="w")
        self.procbox=tk.Text(right,bg="#070b0f",fg=FG,insertbackground=CYAN,relief="flat",font=("DejaVu Sans Mono",9),wrap="word",state="disabled")
        self.procbox.pack(fill="both",expand=True,padx=10,pady=(0,10))

        cron = tk.Frame(ops_page, bg=PANEL, padx=14, pady=10)
        cron.pack(fill="both", padx=14, pady=(0,8))
        head = tk.Frame(cron, bg=PANEL); head.pack(fill="x")
        tk.Label(head,text="CRONOLOGICAL JOB CONTROLS",font=TITLE,fg=CYAN,bg=PANEL).pack(side="left")
        self.cron_count = tk.Label(head,text="SCANNING",font=("DejaVu Sans Mono",9,"bold"),fg=DIM,bg=PANEL)
        self.cron_count.pack(side="right")
        tk.Button(head,text="⟳ SCAN",command=self.refresh_crons,bg="#17222d",fg=CYAN,relief="flat",padx=12).pack(side="right",padx=8)
        tk.Button(head,text="TOGGLE SELECTED",command=self.toggle_selected,bg="#17222d",fg=YELLOW,relief="flat",padx=12).pack(side="right")

        tree_frame = tk.Frame(cron, bg="#070b0f"); tree_frame.pack(fill="both", expand=True, pady=(8,0))
        style = ttk.Style(self)
        style.configure("Ava.Treeview", background="#070b0f", foreground=FG, fieldbackground="#070b0f", rowheight=24, font=("DejaVu Sans Mono",9))
        style.configure("Ava.Treeview.Heading", background="#17222d", foreground=CYAN, font=("DejaVu Sans Mono",9,"bold"))
        self.cron_paths = {}
        self.crontree = ttk.Treeview(tree_frame, columns=("status","path"), show="headings", style="Ava.Treeview", selectmode="browse")
        self.crontree.heading("status", text="STATUS"); self.crontree.heading("path", text="CRON PATH")
        self.crontree.column("status", width=100, stretch=False); self.crontree.column("path", width=1000, stretch=True)
        self.crontree.tag_configure("on", foreground=GREEN); self.crontree.tag_configure("off", foreground=RED)
        scroll=ttk.Scrollbar(tree_frame,orient="vertical",command=self.crontree.yview); self.crontree.configure(yscrollcommand=scroll.set)
        self.crontree.pack(side="left",fill="both",expand=True); scroll.pack(side="right",fill="y")
        self.crontree.bind("<Double-1>", lambda e:self.toggle_selected())

        cli = tk.Frame(ops_page,bg=PANEL,padx=14,pady=10)
        cli.pack(fill="x")
        tk.Label(cli,text="ava-core >",font=("DejaVu Sans Mono",11,"bold"),fg=GREEN,bg=PANEL).pack(side="left")
        self.command=tk.Entry(cli,bg="#070b0f",fg=FG,insertbackground=CYAN,relief="flat",font=FONT)
        self.command.pack(side="left",fill="x",expand=True,padx=10,ipady=6)
        self.command.bind("<Return>",lambda e:self.execute_command())
        tk.Button(cli,text="RUN",command=self.execute_command,bg="#17222d",fg=CYAN,relief="flat",padx=16).pack(side="right")
        self.command.insert(0,"help")


        # AUDIO PAGE
        ahead = tk.Frame(audio_page, bg=PANEL, padx=14, pady=12)
        ahead.pack(fill="x")
        tk.Label(ahead, text="BACKGROUND AUDIO", font=TITLE, fg=CYAN, bg=PANEL).pack(side="left")
        self.audio_count = tk.Label(ahead, text="SCANNING", font=("DejaVu Sans Mono",9,"bold"), fg=DIM, bg=PANEL)
        self.audio_count.pack(side="right")
        tk.Button(ahead, text="⟳ SCAN", command=self.refresh_audio, bg="#17222d", fg=CYAN, relief="flat", padx=12).pack(side="right", padx=8)
        tk.Button(ahead, text="TOGGLE SELECTED", command=self.toggle_selected_audio, bg="#17222d", fg=YELLOW, relief="flat", padx=12).pack(side="right")

        info_audio = tk.Frame(audio_page, bg=BG, padx=0, pady=10)
        info_audio.pack(fill="x")
        self.audio_status = tk.Label(info_audio, text="AUDIO PLAYER: CHECKING", font=("DejaVu Sans Mono",10,"bold"), fg=YELLOW, bg=BG)
        self.audio_status.pack(side="left")
        tk.Label(info_audio, text="Drop MP3 files anywhere under cronologicals/ • rename to .mp3.disabled to turn off",
                 font=("DejaVu Sans Mono",9), fg=DIM, bg=BG).pack(side="right")

        audio_frame = tk.Frame(audio_page, bg=PANEL, padx=14, pady=10)
        audio_frame.pack(fill="both", expand=True)
        style.configure("Audio.Treeview", background="#070b0f", foreground=FG, fieldbackground="#070b0f",
                        rowheight=26, font=("DejaVu Sans Mono",9))
        style.configure("Audio.Treeview.Heading", background="#17222d", foreground=CYAN,
                        font=("DejaVu Sans Mono",9,"bold"))
        self.audio_paths = {}
        self.audiotree = ttk.Treeview(audio_frame, columns=("status","path"), show="headings",
                                      style="Audio.Treeview", selectmode="browse")
        self.audiotree.heading("status", text="STATUS")
        self.audiotree.heading("path", text="AUDIO PATH")
        self.audiotree.column("status", width=100, stretch=False)
        self.audiotree.column("path", width=1000, stretch=True)
        self.audiotree.tag_configure("on", foreground=GREEN)
        self.audiotree.tag_configure("off", foreground=RED)
        ascroll = ttk.Scrollbar(audio_frame, orient="vertical", command=self.audiotree.yview)
        self.audiotree.configure(yscrollcommand=ascroll.set)
        self.audiotree.pack(side="left", fill="both", expand=True)
        ascroll.pack(side="right", fill="y")
        self.audiotree.bind("<Double-1>", lambda e:self.toggle_selected_audio())

        audio_bottom = tk.Frame(audio_page, bg=PANEL, padx=14, pady=10)
        audio_bottom.pack(fill="x", pady=(8,0))
        tk.Button(audio_bottom, text="RESTART AUDIO PLAYER", command=lambda:self.audio_action("restart"),
                  bg="#17222d", fg=CYAN, relief="flat", padx=14, pady=8).pack(side="left")
        tk.Button(audio_bottom, text="VIEW AUDIO LOG", command=self.show_audio_log,
                  bg="#17222d", fg=FG, relief="flat", padx=14, pady=8).pack(side="left", padx=8)



    def state(self, cmd):
        rc,out=run(cmd); return rc==0 and bool(out), out

    def refresh_audio(self):
        selected = self.audiotree.selection()
        selected_path = self.audio_paths.get(selected[0]) if selected else None
        self.audio_paths.clear()
        for item in self.audiotree.get_children():
            self.audiotree.delete(item)
        jobs = audio_jobs()
        on_count = off_count = 0
        for job in jobs:
            enabled = job["enabled"]
            on_count += int(enabled); off_count += int(not enabled)
            iid = self.audiotree.insert("", "end",
                values=("● ON" if enabled else "○ OFF", job["rel"]),
                tags=("on" if enabled else "off",))
            self.audio_paths[iid] = str(job["path"])
            if selected_path == str(job["path"]):
                self.audiotree.selection_set(iid)
        self.audio_count.configure(text=f"{len(jobs)} TRACKS  •  {on_count} ON  •  {off_count} OFF")
        running = run("pgrep -af '[a]va_core_audio_player.py'")[0] == 0
        self.audio_status.configure(text=("AUDIO PLAYER: RUNNING" if running else "AUDIO PLAYER: OFFLINE"),
                                    fg=GREEN if running else RED)

    def toggle_selected_audio(self):
        sel = self.audiotree.selection()
        if not sel:
            messagebox.showinfo("AVA Audio", "Select an MP3 first.")
            return
        path = Path(self.audio_paths.get(sel[0], ""))
        try:
            target, enabled = toggle_audio(path)
            self.show_command_result("audio toggle", f"{'ENABLED' if enabled else 'DISABLED'}\n{target}")
            self.refresh_audio()
        except Exception as e:
            messagebox.showerror("AVA Audio", f"Audio toggle failed:\n{e}")

    def audio_action(self, action):
        cmd = f"pkexec systemctl restart {SERVICE}" if action == "restart" else ""
        if not cmd:
            return
        def worker():
            rc, out = run(cmd, 30)
            self.after(0, lambda:self.show_command_result("restart audio player", out or f"exit={rc}"))
            self.after(1000, self.refresh_audio)
        threading.Thread(target=worker, daemon=True).start()

    def show_audio_log(self):
        p = Path("/home/ava-core/Database/logs/ava-core-audio.log")
        try:
            text = "\n".join(p.read_text(errors="replace").splitlines()[-120:]) if p.exists() else "No audio log yet."
        except Exception as e:
            text = str(e)
        self.set_text(self.procbox, "=== AVA CORE AUDIO LOG ===\n" + text)

    def refresh_crons(self):
        selected = self.crontree.selection()
        selected_path = self.cron_paths.get(selected[0]) if selected else None
        self.cron_paths.clear()
        for item in self.crontree.get_children(): self.crontree.delete(item)
        jobs = cron_jobs()
        on_count = off_count = 0
        for job in jobs:
            enabled = job["enabled"]; on_count += int(enabled); off_count += int(not enabled)
            values = ("● ON" if enabled else "○ OFF", job["rel"])
            iid = self.crontree.insert("", "end", values=values, tags=("on" if enabled else "off",))
            self.cron_paths[iid] = str(job["path"])
            if selected_path == str(job["path"]): self.crontree.selection_set(iid)
        self.cron_count.configure(text=f"{len(jobs)} JOBS  •  {on_count} ON  •  {off_count} OFF")

    def toggle_selected(self):
        sel = self.crontree.selection()
        if not sel:
            messagebox.showinfo("AVA Core","Select a cron job first."); return
        path_str = self.cron_paths.get(sel[0])
        if not path_str: return
        path = Path(path_str)
        try:
            target, enabled = toggle_job(path)
            self.show_command_result("cron toggle", f"{'ENABLED' if enabled else 'DISABLED'}\n{target}")
            self.refresh_crons()
        except Exception as e:
            messagebox.showerror("AVA Core", f"Cron toggle failed:\n{e}")

    def refresh(self):
        def worker():
            active = run(f"systemctl is-active {SERVICE}")[1].strip()=="active"
            enabled = run(f"systemctl is-enabled {SERVICE}")[1].strip()=="enabled"
            dir_on = directory_is_enabled()
            checks = {"service": ("RUNNING" if active else "STOPPED", active),
                      "watchdog": self.state("pgrep -af '[a]vaivy_cloudflare_watchdog.py'"),
                      "broadcast": self.state("pgrep -af '[b]roadcast.py'"),
                      "cloudflared": self.state("pgrep -af '[c]loudflared'"),
                      "port": self.state("ss -ltn 2>/dev/null | grep -q ':8080'"),
                      "directory": ("ON" if dir_on else "OFF", dir_on)}
            proc = run("ps -eo pid,ppid,stat,etime,cmd | grep -E '[p]ython.*ava-core.py|[a]vaivy_cloudflare_watchdog.py|[b]roadcast.py|[c]loudflared'")[1]
            svc = run(f"systemctl --no-pager --full status {SERVICE} | head -25")[1]
            logtext=""
            for p in (LOG,SYSTEMD_LOG):
                if p.exists():
                    try: logtext += f"\n--- {p.name} ---\n" + "\n".join(p.read_text(errors="replace").splitlines()[-80:]) + "\n"
                    except: pass
            self.after(0,lambda:self.apply_refresh(active,enabled,checks,proc,svc,logtext))
        threading.Thread(target=worker,daemon=True).start()

    def apply_refresh(self,active,enabled,checks,proc,svc,logtext):
        for key,val in checks.items():
            text,ok = val if isinstance(val,tuple) else (val,False)
            self.cards[key].configure(text=text,fg=GREEN if ok else RED)
        self.status.configure(text=("● AVA CORE ONLINE" if active else "● AVA CORE OFFLINE"),fg=GREEN if active else RED)
        combined = f"{svc}\n\n=== PROCESS TREE ===\n{proc or 'No managed processes found.'}\n"
        self.set_text(self.procbox,combined); self.set_text(self.logbox,logtext or "No Ava-Core log data found yet.")
        if self.after_id: self.after_cancel(self.after_id)
        self.after_id=self.after(2000,self.refresh)
        self.refresh_audio()

    def do_action(self,action):
        if action=="stop" and not messagebox.askyesno("AVA Core","Stop Ava-Core and its managed processes?"): return
        self.command.delete(0,"end"); self.command.insert(0,action); self.execute_command()

    def execute_command(self):
        raw=self.command.get().strip(); cmd=raw.lower()
        aliases={"status":f"systemctl --no-pager status {SERVICE}","start":f"pkexec systemctl start {SERVICE}",
                 "stop":f"pkexec systemctl stop {SERVICE}","restart":f"pkexec systemctl restart {SERVICE}",
                 "logs":"tail -100 /home/ava-core/Database/logs/ava-core.log",
                 "processes":"ps -eo pid,ppid,stat,etime,cmd | grep -E '[p]ython.*ava-core.py|[a]vaivy_cloudflare_watchdog.py|[b]roadcast.py|[c]loudflared'",
                 "port":"ss -ltnp | grep ':8080'",
                 "help":"Commands: help | status | start | stop | restart | logs | processes | port | refresh | crons | toggle <cron-path> | audio | audio-toggle <audio-path> | audio-log | directory | directory-toggle"}
        if cmd=="refresh": self.refresh(); self.refresh_crons(); return
        if cmd=="crons":
            self.refresh_crons(); self.show_command_result("crons", f"Scanned {CRONO_ROOT}"); return
        if cmd in ("directory", "dir"):
            on = directory_is_enabled()
            self.show_command_result(
                "directory",
                f"status: {'ON' if on else 'OFF'}\n"
                f"url: https://avaivy.cloud/directory\n"
                f"flag: {DIR_FLAG}\n"
                f"disabled-flag: {DIR_FLAG_DISABLED}\n"
                f"Toggle with: directory-toggle",
            )
            return
        if cmd in ("directory-toggle", "dir-toggle"):
            try:
                enabled = toggle_directory()
                self.refresh()
                self.show_command_result(
                    "directory-toggle",
                    f"{'ENABLED' if enabled else 'DISABLED'}\n"
                    f"https://avaivy.cloud/directory\n"
                    f"(broadcast serves the page; restart broadcast only if needed)",
                )
            except Exception as e:
                messagebox.showerror("AVA Directory", str(e))
            return
        if cmd=="audio":
            self.pages.select(1); self.refresh_audio(); self.show_command_result("audio", f"Scanned {CRONO_ROOT} for MP3 files"); return
        if cmd=="audio-log":
            self.show_audio_log(); return
        if raw.lower().startswith("audio-toggle "):
            query=raw[13:].strip()
            matches=[j for j in audio_jobs() if j["rel"]==query or j["path"].name==query]
            if len(matches)!=1:
                messagebox.showwarning("AVA Audio CLI", f"Expected one audio match for: {query}"); return
            try:
                target, enabled=toggle_audio(matches[0]["path"])
                self.refresh_audio()
                self.show_command_result("audio toggle",f"{'ENABLED' if enabled else 'DISABLED'}\n{target}")
            except Exception as e:
                messagebox.showerror("AVA Audio",str(e))
            return
        if raw.lower().startswith("toggle "):
            query=raw[7:].strip()
            matches=[j for j in cron_jobs() if j["rel"]==query or j["path"].name==query]
            if len(matches)!=1: messagebox.showwarning("AVA Core CLI", f"Expected one cron match for: {query}"); return
            try:
                target, enabled=toggle_job(matches[0]["path"]); self.refresh_crons(); self.show_command_result("cron toggle",f"{'ENABLED' if enabled else 'DISABLED'}\n{target}")
            except Exception as e: messagebox.showerror("AVA Core",str(e))
            return
        shell=aliases.get(cmd)
        if not shell: messagebox.showwarning("AVA Core CLI","Unknown command.\nType: help"); return
        self.command.delete(0,"end"); self.command.insert(0,cmd)
        def worker():
            rc,out=run(shell,30); self.after(0,lambda:self.show_command_result(cmd,out or f"exit={rc}")); self.after(0,self.refresh)
        threading.Thread(target=worker,daemon=True).start()

    def show_command_result(self,cmd,out):
        self.procbox.configure(state="normal"); self.procbox.insert("end",f"\n\n$ {cmd}\n{out}\n"); self.procbox.see("end"); self.procbox.configure(state="disabled")

if __name__=="__main__":
    App().mainloop()
