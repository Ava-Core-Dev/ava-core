#!/usr/bin/env python3
"""
ecoflow-enhance.py — Minute aggregator + insight builder

Drop into:
  /home/ava-core/operations/cronologicals/since-last-fire/every-minute/

What it does:
  1. Reads all rows currently in ecoflow-data.db (the 10-second captures)
  2. Renames devices:
       R331ZAB5SG755642  →  security
       R621ZA16XH6K1155  →  Primary
       R331ZAB5SG6S2858  →  Backup
  3. Aggregates every SN into one rich summary row (averages, min/max, deltas…)
  4. Writes the summary into ecoflow-data-enhanced.db
  5. Appends a human-readable line to ecoflow-enhanced-log.txt
  6. Clears (resets) ecoflow-data.db so the next minute starts fresh
"""

import sqlite3
import json
import logging
import sys
from datetime import datetime, timezone
from pathlib import Path
from statistics import mean, median, stdev
from collections import defaultdict

# ── paths ──────────────────────────────────────────────────────────────
ECO_DIR   = Path("/home/ava-core/Database/ecoflow")
SRC_DB    = ECO_DIR / "ecoflow-data.db"
DST_DB    = ECO_DIR / "ecoflow-data-enhanced.db"
LOG_FILE  = ECO_DIR / "ecoflow-enhanced-log.txt"
MAIN_LOG  = Path("/home/ava-core/Database/logs") / "ecoflow-enhance.log"

MAIN_LOG.parent.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-7s  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[
        logging.FileHandler(MAIN_LOG),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger("ecoflow-enhance")

# ── device rename map (SN → friendly name) ─────────────────────────────
NAME_MAP = {
    "R331ZAB5SG755642": "security",      # was Robin/AC to go
    "R621ZA16XH6K1155": "Primary",       # was RIVER 2 Pro-1155
    "R331ZAB5SG6S2858": "Backup",        # was Backup
}

def friendly(sn: str, fallback: str = "") -> str:
    return NAME_MAP.get(sn, fallback or sn)

# ── helpers ────────────────────────────────────────────────────────────
def safe_mean(vals):
    vals = [v for v in vals if v is not None]
    return round(mean(vals), 2) if vals else None

def safe_median(vals):
    vals = [v for v in vals if v is not None]
    return round(median(vals), 2) if vals else None

def safe_stdev(vals):
    vals = [v for v in vals if v is not None]
    return round(stdev(vals), 2) if len(vals) > 1 else 0.0

def safe_min(vals):
    vals = [v for v in vals if v is not None]
    return min(vals) if vals else None

def safe_max(vals):
    vals = [v for v in vals if v is not None]
    return max(vals) if vals else None

def delta(vals):
    """Last − first (positive = rising)."""
    vals = [v for v in vals if v is not None]
    if len(vals) < 2:
        return 0.0
    return round(vals[-1] - vals[0], 2)

# ── database setup ─────────────────────────────────────────────────────
def init_enhanced_db(path: Path):
    conn = sqlite3.connect(path)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS minute_summary (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            ts              TEXT NOT NULL,          -- UTC ISO of aggregation
            minute_key      TEXT NOT NULL,          -- YYYY-MM-DD HH:MM
            sn              TEXT NOT NULL,
            name            TEXT NOT NULL,
            samples         INTEGER,

            -- core averages
            soc_avg         REAL,
            soc_min         REAL,
            soc_max         REAL,
            soc_delta       REAL,
            soc_stdev       REAL,

            in_w_avg        REAL,
            in_w_min        REAL,
            in_w_max        REAL,
            in_w_delta      REAL,

            out_w_avg       REAL,
            out_w_min       REAL,
            out_w_max       REAL,
            out_w_delta     REAL,

            solar_w_avg     REAL,
            solar_w_min     REAL,
            solar_w_max     REAL,

            -- derived insight
            net_w_avg       REAL,          -- in − out
            load_ratio      REAL,          -- out / (in+0.01)
            energy_in_wh    REAL,          -- rough Wh for the minute
            energy_out_wh   REAL,
            online_pct      REAL,          -- % of samples that reported online
            trend           TEXT,          -- rising / falling / stable

            raw_samples     TEXT,          -- JSON list of the raw points
            created_at      TEXT DEFAULT (datetime('now'))
        )
    """)
    cur.execute("CREATE INDEX IF NOT EXISTS idx_min_sn ON minute_summary(sn, minute_key)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_min_name ON minute_summary(name, minute_key)")
    conn.commit()
    return conn

# ── main logic ─────────────────────────────────────────────────────────
def main():
    log.info("ecoflow-enhance starting")

    if not SRC_DB.exists():
        log.warning(f"Source DB not found: {SRC_DB} — nothing to enhance")
        return

    # read all current snapshots
    src = sqlite3.connect(SRC_DB)
    src.row_factory = sqlite3.Row
    rows = src.execute("""
        SELECT ts, sn, online, soc, in_w, out_w, solar_w, raw_json
        FROM snapshots
        ORDER BY ts
    """).fetchall()
    src.close()

    if not rows:
        log.info("No snapshots in source DB — nothing to do")
        return

    log.info(f"Loaded {len(rows)} snapshot(s) from source DB")

    # group by SN
    by_sn = defaultdict(list)
    for r in rows:
        by_sn[r["sn"]].append(dict(r))

    now = datetime.now(timezone.utc)
    minute_key = now.strftime("%Y-%m-%d %H:%M")
    ts_iso = now.isoformat()

    dst = init_enhanced_db(DST_DB)
    log_lines = []

    for sn, samples in by_sn.items():
        name = friendly(sn)
        n = len(samples)

        socs   = [s["soc"]     for s in samples]
        ins    = [s["in_w"]    for s in samples]
        outs   = [s["out_w"]   for s in samples]
        solars = [s["solar_w"] for s in samples]
        onlines = [s["online"] for s in samples if s["online"] is not None]

        soc_avg   = safe_mean(socs)
        in_avg    = safe_mean(ins)
        out_avg   = safe_mean(outs)
        solar_avg = safe_mean(solars)

        soc_d = delta(socs)
        in_d  = delta(ins)
        out_d = delta(outs)

        # trend based on SOC movement
        if soc_d is None:
            trend = "unknown"
        elif abs(soc_d) < 0.3:
            trend = "stable"
        elif soc_d > 0:
            trend = "rising"
        else:
            trend = "falling"

        net_w = None
        if in_avg is not None and out_avg is not None:
            net_w = round(in_avg - out_avg, 2)

        load_ratio = None
        if in_avg is not None and out_avg is not None:
            load_ratio = round(out_avg / (in_avg + 0.01), 3)

        # rough energy for the window (samples are ~10 s apart)
        # Wh ≈ average_watts * (n * 10 / 3600)
        window_h = (n * 10) / 3600.0
        energy_in  = round(in_avg  * window_h, 3) if in_avg  is not None else None
        energy_out = round(out_avg * window_h, 3) if out_avg is not None else None

        online_pct = None
        if onlines:
            online_pct = round(100.0 * sum(1 for o in onlines if o) / len(onlines), 1)

        # store
        dst.execute("""
            INSERT INTO minute_summary (
                ts, minute_key, sn, name, samples,
                soc_avg, soc_min, soc_max, soc_delta, soc_stdev,
                in_w_avg, in_w_min, in_w_max, in_w_delta,
                out_w_avg, out_w_min, out_w_max, out_w_delta,
                solar_w_avg, solar_w_min, solar_w_max,
                net_w_avg, load_ratio, energy_in_wh, energy_out_wh,
                online_pct, trend, raw_samples
            ) VALUES (?,?,?,?,?,  ?,?,?,?,?,  ?,?,?,?,  ?,?,?,?,  ?,?,?,  ?,?,?,?,  ?,?,?)
        """, (
            ts_iso, minute_key, sn, name, n,
            soc_avg, safe_min(socs), safe_max(socs), soc_d, safe_stdev(socs),
            in_avg, safe_min(ins), safe_max(ins), in_d,
            out_avg, safe_min(outs), safe_max(outs), out_d,
            solar_avg, safe_min(solars), safe_max(solars),
            net_w, load_ratio, energy_in, energy_out,
            online_pct, trend,
            json.dumps([{
                "ts": s["ts"], "soc": s["soc"], "in": s["in_w"],
                "out": s["out_w"], "solar": s["solar_w"], "online": s["online"]
            } for s in samples]),
        ))

        line = (
            f"{minute_key}  {name:10s}  "
            f"soc={soc_avg:>5} ({trend})  "
            f"in={in_avg:>6}W  out={out_avg:>6}W  "
            f"net={net_w:>7}W  samples={n}"
        )
        log_lines.append(line)
        log.info(line)

    dst.commit()
    dst.close()
    log.info(f"Wrote {len(by_sn)} summary row(s) → {DST_DB}")

    # append human log
    with open(LOG_FILE, "a") as f:
        f.write(f"\n--- {ts_iso} ---\n")
        for line in log_lines:
            f.write(line + "\n")
    log.info(f"Appended to {LOG_FILE}")

    # ── reset source DB ────────────────────────────────────────────────
    log.info("Resetting source ecoflow-data.db …")
    src = sqlite3.connect(SRC_DB)
    src.execute("DELETE FROM snapshots")
    src.execute("DELETE FROM devices")
    src.commit()
    # reclaim space
    src.execute("VACUUM")
    src.close()
    log.info("Source DB cleared and vacuumed")

    log.info("ecoflow-enhance finished")

if __name__ == "__main__":
    main()
