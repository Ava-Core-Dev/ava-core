#!/usr/bin/env python3
"""
fetch_weather_hourly.py

Hourly weather fetcher for Hawaiian locations.

- Runs safely (lockfile) and enforces an interval in-DB (defaults to 1 hour).
- Fetches from Open-Meteo and NOAA/NWS (api.weather.gov).
- Deduplicates/upserts by (location_id, provider, obs_ts).
- Stores raw JSON and parsed numeric fields.
- Stores daily sunrise/sunset in a dedicated table (upserted by date).
- Implements per-request pacing and retry/backoff on transient errors.
- CLI: --force, --dry-run, --verbose

Install:
  sudo mkdir -p /home/ava-core/bin
  (save this file to /home/ava-core/bin/fetch_weather_hourly.py)
  sudo chmod +x /home/ava-core/bin/fetch_weather_hourly.py
  sudo chown ava-core:ava-core /home/ava-core/bin/fetch_weather_hourly.py

Warning: Set NWS_USER_AGENT to a contact-bearing string per NWS policy.
"""
from __future__ import annotations

import json
import os
import sqlite3
import sys
import time
import math
from datetime import datetime, timezone, date
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

# Try requests, fallback to urllib
try:
    import requests  # type: ignore

    def http_get(url: str, headers: dict | None = None, params: dict | None = None, timeout: int = 20):
        r = requests.get(url, headers=headers or {}, params=params or {}, timeout=timeout)
        r.raise_for_status()
        return r.status_code, r.text, r.headers.get("Content-Type", "")
except Exception:
    import urllib.request, urllib.parse, ssl

    ssl_ctx = ssl.create_default_context()

    def http_get(url: str, headers: dict | None = None, params: dict | None = None, timeout: int = 20):
        if params:
            url = url + ("?" + urllib.parse.urlencode(params))
        req = urllib.request.Request(url, headers=headers or {}, method="GET")
        with urllib.request.urlopen(req, timeout=timeout, context=ssl_ctx) as resp:
            data = resp.read()
            ct = resp.getheader("Content-Type")
            return resp.status, data.decode("utf-8", errors="replace"), ct or ""


# ---------- Config ----------
DB_DIR = Path("/home/ava-core/database")
DB_PATH = DB_DIR / "weather.db"
LOCK_PATH = Path("/tmp/fetch_weather_hourly.lock")

# IMPORTANT: update with a valid contact per NWS policy (email or URL)
NWS_USER_AGENT = "ava-core-weather/1.0 (ops@example.com)"

# Run spacing (1 hour)
MIN_SECONDS_BETWEEN_RUNS = 1 * 3600

# Per-request pacing and retries
PER_REQUEST_DELAY = 0.18  # seconds between requests to avoid bursts
MAX_RETRIES = 3
RETRY_BASE = 1.0  # backoff base seconds

# Canonical public weather registry. Keep collection and public pages on one source of truth.
HAWAII_LOCATIONS_PATH = Path("/home/ava-core/web/sites/avaivy.cloud/data/hawaii-locations.json")
if not HAWAII_LOCATIONS_PATH.is_file():
    HAWAII_LOCATIONS_PATH = Path(__file__).resolve().parents[4] / "web/sites/avaivy.cloud/data/hawaii-locations.json"

def load_hawaii_locations():
    data = json.loads(HAWAII_LOCATIONS_PATH.read_text(encoding="utf-8"))
    rows = []
    for island in data.get("islands", []):
        for loc in island.get("locations", []):
            rows.append({"island": island["name"], "name": loc["name"], "slug": loc["slug"], "lat": loc["lat"], "lon": loc["lon"]})
    return rows

LOCATIONS = load_hawaii_locations()


# ---------- DB helpers ----------
def ensure_db() -> None:
    DB_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    c = conn.cursor()
    c.execute(
        """
        CREATE TABLE IF NOT EXISTS meta (
            k TEXT PRIMARY KEY,
            v TEXT
        )
        """
    )
    c.execute(
        """
        CREATE TABLE IF NOT EXISTS locations (
            id INTEGER PRIMARY KEY,
            island TEXT,
            name TEXT,
            lat REAL,
            lon REAL,
            country_code TEXT DEFAULT 'US',
            admin1_code TEXT DEFAULT 'HI',
            region TEXT,
            UNIQUE(island,name)
        )
        """
    )
    # weather rows: unique by (location,provider,obs_ts)
    c.execute(
        """
        CREATE TABLE IF NOT EXISTS weather (
            id INTEGER PRIMARY KEY,
            location_id INTEGER,
            provider TEXT,
            obs_ts TEXT,            -- provider observation timestamp (ISO)
            forecast_from TEXT,     -- optional forecast valid-from
            forecast_to TEXT,       -- optional forecast valid-to
            ts_utc TEXT,            -- when we fetched it (UTC ISO)
            raw TEXT,
            temp_c REAL,
            wind_kph REAL,
            wind_deg REAL,
            precipitation_mm REAL,
            humidity_pct REAL,
            cloud_pct REAL,
            created_at TEXT,
            updated_at TEXT,
            UNIQUE(location_id, provider, obs_ts)
        )
        """
    )
    for col, definition in (("country_code", "TEXT"), ("admin1_code", "TEXT"), ("region", "TEXT")):
        try:
            c.execute(f"ALTER TABLE locations ADD COLUMN {col} {definition}")
        except sqlite3.OperationalError:
            pass
    c.execute("UPDATE locations SET country_code=COALESCE(country_code,'US'), admin1_code=COALESCE(admin1_code,'HI'), region=COALESCE(region,island)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_weather_obs_ts ON weather(obs_ts)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_weather_location ON weather(location_id)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_weather_provider ON weather(provider)")

    # daily sun times per location/date
    c.execute(
        """
        CREATE TABLE IF NOT EXISTS daily_sun (
            id INTEGER PRIMARY KEY,
            location_id INTEGER,
            date TEXT,            -- YYYY-MM-DD (local)
            sunrise TEXT,
            sunset TEXT,
            created_at TEXT,
            updated_at TEXT,
            UNIQUE(location_id, date)
        )
        """
    )
    conn.commit()
    conn.close()


def save_location_if_missing(conn: sqlite3.Connection, loc: Dict[str, Any]) -> int:
    cur = conn.cursor()
    cur.execute("SELECT id FROM locations WHERE island=? AND name=?", (loc["island"], loc["name"]))
    r = cur.fetchone()
    if r:
        return int(r[0])
    cur.execute(
        "INSERT INTO locations (island,name,lat,lon,country_code,admin1_code,region) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (loc["island"], loc["name"], float(loc["lat"]), float(loc["lon"]),
         loc.get("country_code", "US"), loc.get("admin1_code", "HI"), loc.get("region", loc["island"])),
    )
    conn.commit()
    return cur.lastrowid


def meta_get(conn: sqlite3.Connection, key: str) -> Optional[str]:
    cur = conn.cursor()
    cur.execute("SELECT v FROM meta WHERE k=?", (key,))
    r = cur.fetchone()
    return r[0] if r else None


def meta_set(conn: sqlite3.Connection, key: str, val: str) -> None:
    cur = conn.cursor()
    cur.execute("INSERT OR REPLACE INTO meta (k,v) VALUES (?, ?)", (key, val))
    conn.commit()


# ---------- HTTP helpers with retries ----------
def fetch_with_retries(url: str, headers: dict | None = None, params: dict | None = None, verbose: bool = False) -> Tuple[Optional[dict], Optional[str]]:
    """
    Returns (parsed_json_or_None, error_message_or_None)
    Retries on transient HTTP errors with exponential backoff.
    """
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            status, text, _ct = http_get(url, headers=headers, params=params, timeout=20)
            # parse JSON if possible
            try:
                obj = json.loads(text)
            except Exception:
                obj = None
            # success
            return obj, None
        except Exception as e:
            # On last attempt return error
            if attempt == MAX_RETRIES:
                return None, f"{e}"
            # backoff a bit
            backoff = RETRY_BASE * (2 ** (attempt - 1)) + (attempt * 0.1)
            if verbose:
                print(f"Fetch failed (attempt {attempt}) for {url}: {e}; backing off {backoff:.1f}s")
            time.sleep(backoff)
    return None, "max retries exceeded"


# ---------- Provider fetchers ----------
def fetch_open_meteo(lat: float, lon: float, verbose: bool = False) -> Tuple[Optional[dict], Optional[str]]:
    params = {
        "latitude": lat,
        "longitude": lon,
        "current_weather": "true",
        "hourly": "relativehumidity_2m,precipitation,temperature_2m,windspeed_10m,winddirection_10m,cloudcover",
        "daily": "sunrise,sunset",
        "timezone": "auto",
    }
    url = "https://api.open-meteo.com/v1/forecast"
    return fetch_with_retries(url, headers=None, params=params, verbose=verbose)


def fetch_noaa_nws(lat: float, lon: float, verbose: bool = False) -> Tuple[Optional[dict], Optional[str]]:
    """
    Fetch the NWS point metadata, then retrieve the latest observation
    from the first available observation station.

    Do not request:
        /gridpoints/{office}/{x},{y}/observations

    That is not a valid NWS observations endpoint and returns 404.
    """

    headers = {
        "User-Agent": NWS_USER_AGENT,
        "Accept": "application/geo+json",
    }

    base = f"https://api.weather.gov/points/{lat},{lon}"

    # Step 1: resolve the geographic point.
    pts, err = fetch_with_retries(
        base,
        headers=headers,
        verbose=verbose,
    )

    if pts is None:
        return None, f"points error: {err}"

    out: dict = {
        "points": pts
    }

    props = pts.get("properties", {}) if isinstance(pts, dict) else {}

    # Step 2: obtain the observation station list supplied by NWS.
    stations_link = props.get("observationStations")

    if not stations_link or not isinstance(stations_link, str):
        out["stations_list_error"] = "No observationStations URL returned"
        return out, None

    st_list, s_err = fetch_with_retries(
        stations_link,
        headers=headers,
        verbose=verbose,
    )

    if st_list is None:
        out["stations_list_error"] = s_err
        return out, None

    out["stations_list"] = st_list

    features = st_list.get("features") or []

    if not features:
        out["station_latest_error"] = "No observation stations returned"
        return out, None

    # Use the first station returned by the NWS point service.
    station = features[0]

    if not isinstance(station, dict):
        out["station_latest_error"] = "Invalid station record"
        return out, None

    st_id = station.get("id")

    if not st_id or not isinstance(st_id, str):
        out["station_latest_error"] = "Station ID missing"
        return out, None

    out["station_id"] = st_id

    # Step 3: retrieve the latest observation for that station.
    latest_url = st_id.rstrip("/") + "/observations/latest"

    latest, lerr = fetch_with_retries(
        latest_url,
        headers=headers,
        verbose=verbose,
    )

    if latest is not None:
        out["station_latest"] = latest
    else:
        out["station_latest_error"] = lerr

    return out, None

# ---------- Parsers ----------
def parse_open_meteo(obj: dict) -> Tuple[Optional[str], Optional[float], Optional[float], Optional[float], Optional[float], Optional[float], Optional[str], Optional[str]]:
    """
    Returns:
      obs_ts_iso, temp_c, wind_kph, wind_deg, precipitation_mm, humidity_pct, sunrise_iso, sunset_iso
    """
    obs_ts = None
    temp_c = wind_kph = wind_deg = precipitation_mm = humidity_pct = None
    sunrise_iso = sunset_iso = None
    try:
        cur = obj.get("current_weather") or {}
        if cur:
            obs_ts = cur.get("time")
            temp_c = cur.get("temperature")
            wind_kph = cur.get("windspeed")
            wind_deg = cur.get("winddirection")
        # precipitation/humidity: attempt hourly near-now
        hourly = obj.get("hourly") or {}
        if hourly:
            times = hourly.get("time", [])
            precs = hourly.get("precipitation", [])
            rh = hourly.get("relativehumidity_2m", [])
            if times and (precs or rh):
                # prefer the last entry
                if precs and len(precs) == len(times):
                    precipitation_mm = float(precs[-1]) if precs[-1] is not None else None
                if rh and len(rh) == len(times):
                    humidity_pct = float(rh[-1]) if rh[-1] is not None else None
        daily = obj.get("daily") or {}
        if daily:
            dtimes = daily.get("time", [])
            rises = daily.get("sunrise", [])
            sets = daily.get("sunset", [])
            if dtimes and rises and sets:
                today = date.today().isoformat()
                # find today's index if possible
                for i, t in enumerate(dtimes):
                    if t.startswith(today):
                        sunrise_iso = rises[i]
                        sunset_iso = sets[i]
                        break
                if sunrise_iso is None and dtimes:
                    sunrise_iso = rises[0] if rises else None
                    sunset_iso = sets[0] if sets else None
    except Exception:
        pass
    return obs_ts, temp_c, wind_kph, wind_deg, precipitation_mm, humidity_pct, sunrise_iso, sunset_iso


def parse_nws(obj: dict) -> Tuple[Optional[str], Optional[float], Optional[float], Optional[float], Optional[float]]:
    """
    Returns: obs_ts_iso, temp_c, wind_kph, wind_deg, humidity_pct
    """
    obs_ts = None
    temp_c = wind_kph = wind_deg = humidity_pct = None
    try:
        # station_latest preferred
        if obj.get("station_latest"):
            p = obj["station_latest"].get("properties", {})
            # possible timestamp fields
            obs_ts = p.get("timestamp") or p.get("validTime") or p.get("observation_time")
            if isinstance(obs_ts, dict):
                obs_ts = obs_ts.get("value")
            # temp in Celsius
            t = p.get("temperature", {}).get("value")
            if t is not None:
                temp_c = float(t)
            wind_ms = p.get("windSpeed", {}).get("value")
            if wind_ms is not None:
                wind_kph = float(wind_ms) * 3.6
            wind_deg = p.get("windDirection", {}).get("value")
            humidity_pct = p.get("relativeHumidity", {}).get("value")
        elif obj.get("grid_observations"):
            features = obj["grid_observations"].get("features") or []
            if features:
                p = features[0].get("properties", {})
                obs_ts = p.get("timestamp") or p.get("validTime")
                t = p.get("temperature", {}).get("value")
                if t is not None:
                    temp_c = float(t)
                wind_ms = p.get("windSpeed", {}).get("value")
                if wind_ms is not None:
                    wind_kph = float(wind_ms) * 3.6
                wind_deg = p.get("windDirection", {}).get("value")
                humidity_pct = p.get("relativeHumidity", {}).get("value")
    except Exception:
        pass
    return obs_ts, temp_c, wind_kph, wind_deg, humidity_pct


# ---------- Upsert helpers ----------
def upsert_weather(conn: sqlite3.Connection, location_id: int, provider: str, obs_ts: Optional[str], forecast_from: Optional[str], forecast_to: Optional[str], raw_obj: dict, temp_c: Optional[float], wind_kph: Optional[float], wind_deg: Optional[float], precipitation_mm: Optional[float], humidity_pct: Optional[float], cloud_pct: Optional[float], dry_run: bool = False) -> Tuple[bool, bool]:
    """
    Performs upsert. Returns (inserted, updated)
    """
    cur = conn.cursor()
    key_obs = obs_ts or ""
    # check existing
    cur.execute("SELECT id FROM weather WHERE location_id=? AND provider=? AND obs_ts=?", (location_id, provider, key_obs))
    existing = cur.fetchone()
    now_iso = datetime.now(timezone.utc).isoformat()
    raw = json.dumps(raw_obj)
    if dry_run:
        return (existing is None, existing is not None)
    if existing:
        # update
        cur.execute(
            """
            UPDATE weather SET
                ts_utc=?,
                raw=?,
                temp_c=?,
                wind_kph=?,
                wind_deg=?,
                precipitation_mm=?,
                humidity_pct=?,
                cloud_pct=?,
                forecast_from=?,
                forecast_to=?,
                updated_at=?
            WHERE id=?
            """,
            (now_iso, raw, temp_c, wind_kph, wind_deg, precipitation_mm, humidity_pct, cloud_pct, forecast_from, forecast_to, now_iso, existing[0]),
        )
        conn.commit()
        return False, True
    else:
        cur.execute(
            """
            INSERT INTO weather
            (location_id, provider, obs_ts, forecast_from, forecast_to, ts_utc, raw, temp_c, wind_kph, wind_deg, precipitation_mm, humidity_pct, cloud_pct, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                location_id,
                provider,
                key_obs,
                forecast_from,
                forecast_to,
                now_iso,
                raw,
                temp_c,
                wind_kph,
                wind_deg,
                precipitation_mm,
                humidity_pct,
                cloud_pct,
                now_iso,
                now_iso,
            ),
        )
        conn.commit()
        return True, False


def upsert_daily_sun(conn: sqlite3.Connection, location_id: int, sunrise_iso: Optional[str], sunset_iso: Optional[str], sunrise_date: Optional[str], dry_run: bool = False) -> Tuple[bool, bool]:
    """
    date is sunrise_date in YYYY-MM-DD local; returns (inserted, updated)
    """
    if not sunrise_date:
        return False, False
    cur = conn.cursor()
    cur.execute("SELECT id FROM daily_sun WHERE location_id=? AND date=?", (location_id, sunrise_date))
    existing = cur.fetchone()
    now_iso = datetime.now(timezone.utc).isoformat()
    if dry_run:
        return (existing is None, existing is not None)
    if existing:
        cur.execute(
            "UPDATE daily_sun SET sunrise=?, sunset=?, updated_at=? WHERE id=?",
            (sunrise_iso, sunset_iso, now_iso, existing[0]),
        )
        conn.commit()
        return False, True
    else:
        cur.execute(
            "INSERT INTO daily_sun (location_id, date, sunrise, sunset, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)",
            (location_id, sunrise_date, sunrise_iso, sunset_iso, now_iso, now_iso),
        )
        conn.commit()
        return True, False


# ---------- Lock helpers ----------
def acquire_lock() -> bool:
    try:
        if LOCK_PATH.exists():
            pid_text = LOCK_PATH.read_text(errors="ignore").strip()
            if pid_text:
                try:
                    pid = int(pid_text)
                    os.kill(pid, 0)
                    # still alive
                    return False
                except Exception:
                    try:
                        LOCK_PATH.unlink()
                    except Exception:
                        pass
        LOCK_PATH.write_text(str(os.getpid()))
        return True
    except Exception:
        return False


def release_lock() -> None:
    try:
        if LOCK_PATH.exists():
            LOCK_PATH.unlink()
    except Exception:
        pass


# ---------- Main run ----------
def run_once(force: bool = False, dry_run: bool = False, verbose: bool = False) -> None:
    ensure_db()
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row

    # check last run
    last = meta_get(conn, "last_run")
    last_ts = float(last) if last else 0.0
    now_ts = time.time()
    if not force and (now_ts - last_ts) < MIN_SECONDS_BETWEEN_RUNS:
        if verbose:
            rem = int(MIN_SECONDS_BETWEEN_RUNS - (now_ts - last_ts))
            print(f"Skipping run: last run {int(now_ts-last_ts)}s ago; need {MIN_SECONDS_BETWEEN_RUNS}s. Use --force to override.")
        conn.close()
        return

    if not acquire_lock():
        if verbose:
            print("Another instance appears to be running; exiting.")
        conn.close()
        return

    total_new = 0
    total_updated = 0
    total_errors = 0
    try:
        for idx, loc in enumerate(LOCATIONS):
            if verbose:
                print(f"[{idx+1}/{len(LOCATIONS)}] {loc['island']} / {loc['name']} ({loc['lat']},{loc['lon']})")
            loc_id = save_location_if_missing(conn, loc)

            # OPEN-METEO
            om_obj, om_err = fetch_open_meteo(loc["lat"], loc["lon"], verbose=verbose)
            time.sleep(PER_REQUEST_DELAY)
            if om_obj:
                obs_ts, temp_c, wind_kph, wind_deg, precipitation_mm, humidity_pct, sunrise_iso, sunset_iso = parse_open_meteo(om_obj)
                # For sunrise date use local date from sunrise timestamp if present, else today's date
                sun_date = None
                if sunrise_iso:
                    try:
                        sun_date = sunrise_iso.split("T", 1)[0]
                    except Exception:
                        sun_date = date.today().isoformat()
                else:
                    sun_date = date.today().isoformat()
                # Extract one scalar cloud-cover value for the observation.
                # Open-Meteo hourly.cloudcover is an array and cannot be bound
                # directly into a SQLite scalar column.
                cloud_pct = None
                hourly = om_obj.get("hourly", {})
                if isinstance(hourly, dict):
                    cloud_values = hourly.get("cloudcover")
                    hourly_times = hourly.get("time")

                    if isinstance(cloud_values, list) and cloud_values:
                        # Prefer the cloud-cover entry matching obs_ts.
                        if obs_ts and isinstance(hourly_times, list):
                            try:
                                obs_key = str(obs_ts).replace("Z", "+00:00")[:16]
                                for i, t in enumerate(hourly_times):
                                    if str(t).replace("Z", "+00:00")[:16] == obs_key:
                                        if i < len(cloud_values):
                                            cloud_pct = cloud_values[i]
                                        break
                            except Exception:
                                pass

                        # Safe fallback: use the first scalar value.
                        if cloud_pct is None:
                            cloud_pct = cloud_values[0]

                # SQLite requires a scalar value, not a list/dict.
                if isinstance(cloud_pct, (list, dict)):
                    cloud_pct = None

                ins, upd = upsert_weather(
                    conn,
                    loc_id,
                    "open-meteo",
                    obs_ts,
                    None,
                    None,
                    om_obj,
                    temp_c,
                    wind_kph,
                    wind_deg,
                    precipitation_mm,
                    humidity_pct,
                    cloud_pct,
                    dry_run=dry_run,
                )
                if ins:
                    total_new += 1
                if upd:
                    total_updated += 1
                s_ins, s_upd = upsert_daily_sun(conn, loc_id, sunrise_iso, sunset_iso, sun_date, dry_run=dry_run)
                if verbose:
                    print(f"  open-meteo -> inserted={ins} updated={upd} sun_inserted={s_ins} sun_updated={s_upd}")
            else:
                total_errors += 1
                if verbose:
                    print(f"  open-meteo error: {om_err}")

            # NWS
            nws_obj, nws_err = fetch_noaa_nws(loc["lat"], loc["lon"], verbose=verbose)
            time.sleep(PER_REQUEST_DELAY)
            if nws_obj:
                n_obs_ts, n_temp_c, n_wind_kph, n_wind_deg, n_humidity = parse_nws(nws_obj)
                ins, upd = upsert_weather(conn, loc_id, "nws", n_obs_ts, None, None, nws_obj, n_temp_c, n_wind_kph, n_wind_deg, None, n_humidity, None, dry_run=dry_run)
                if ins:
                    total_new += 1
                if upd:
                    total_updated += 1
                if verbose:
                    print(f"  nws -> inserted={ins} updated={upd}")
            else:
                total_errors += 1
                if verbose:
                    print(f"  nws error: {nws_err}")

        # set last_run meta
        if not dry_run:
            meta_set(conn, "last_run", str(now_ts))
            meta_set(conn, "last_successful_run", datetime.now(timezone.utc).isoformat())
        if verbose:
            print(f"Run summary: new={total_new} updated={total_updated} errors={total_errors}")
    finally:
        release_lock()
        conn.close()


# ---------- CLI ----------
def main():
    import argparse

    p = argparse.ArgumentParser(description="Hourly weather fetcher (Open-Meteo + NWS) for Hawaiian locations")
    p.add_argument("--force", action="store_true", help="Ignore interval check and run now")
    p.add_argument("--dry-run", action="store_true", help="Do not write DB; just fetch/parse and report")
    p.add_argument("--verbose", action="store_true", help="Verbose output")
    args = p.parse_args()

    run_once(force=args.force, dry_run=args.dry_run, verbose=args.verbose)


if __name__ == "__main__":
    main()