# Ava Ivy state news collectors

Each state gets its own `news.py` under `operations/news/<state>/`.

The collector itself does only collection/normalization/deduplication. Scheduling is owned by Cronologicals.

Current state:

- `hawaii/news.py` — Hawaiʻi source collector

Do not add independent system cron entries for these collectors. Put the launcher in the appropriate `operations/cronologicals/on-time/HH:MM/` slot.
