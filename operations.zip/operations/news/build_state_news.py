#!/usr/bin/env python3
"""
Ava Ivy — State News Builder

Runs every existing state news collector using the existing
operations/news/<state>/news.py structure.

Rules:
- Do not replace the existing state collectors.
- Do not create duplicate databases.
- Empty state databases receive the existing bounded backfill.
- Existing populated databases receive a normal incremental poll.
- One failed state does not stop the remaining states.
"""

from __future__ import annotations

from pathlib import Path
import subprocess
import sys
import sqlite3
from datetime import datetime, timezone


ROOT = Path("/home/ava-core")
NEWS_ROOT = ROOT / "operations" / "news"
STATE_DB_ROOT = ROOT / "database" / "states"


def state_db_has_posts(db: Path) -> bool:
    if not db.is_file():
        return False

    try:
        con = sqlite3.connect(str(db))
        try:
            row = con.execute(
                "SELECT COUNT(*) FROM posts"
            ).fetchone()
            return bool(row and row[0])
        finally:
            con.close()
    except Exception:
        return False


def run_state(state_dir: Path) -> dict:
    state = state_dir.name
    collector = state_dir / "news.py"
    db = STATE_DB_ROOT / state / f"{state}_news.db"

    if not collector.is_file():
        return {
            "state": state,
            "status": "missing",
            "posts": False,
        }

    # Empty/new state gets the collector's bounded historical backfill.
    # Once it has data, subsequent runs are normal incremental polls.
    backfill = not state_db_has_posts(db)

    command = [sys.executable, str(collector)]

    if backfill:
        command.append("--backfill")

    started = datetime.now(timezone.utc).isoformat()

    try:
        result = subprocess.run(
            command,
            cwd=str(ROOT),
            text=True,
            capture_output=True,
            timeout=120,
        )

        return {
            "state": state,
            "status": "ok" if result.returncode == 0 else "failed",
            "backfill": backfill,
            "returncode": result.returncode,
            "stdout": result.stdout.strip(),
            "stderr": result.stderr.strip(),
            "started": started,
        }

    except subprocess.TimeoutExpired:
        return {
            "state": state,
            "status": "timeout",
            "backfill": backfill,
            "started": started,
        }

    except Exception as exc:
        return {
            "state": state,
            "status": "error",
            "backfill": backfill,
            "error": repr(exc),
            "started": started,
        }


def main() -> int:
    if not NEWS_ROOT.is_dir():
        print(f"ERROR: missing news directory: {NEWS_ROOT}")
        return 1

    state_dirs = sorted(
        p for p in NEWS_ROOT.iterdir()
        if p.is_dir()
        and (p / "news.py").is_file()
        and not p.name.startswith("_")
    )

    if not state_dirs:
        print("ERROR: no state news collectors found.")
        return 1

    print("=" * 64)
    print("AVA IVY STATE NEWS BUILDER")
    print("=" * 64)
    print()
    print(f"Collectors found: {len(state_dirs)}")
    print()

    results = []

    for state_dir in state_dirs:
        state = state_dir.name
        print(f"[{state}] collecting...", flush=True)

        result = run_state(state_dir)
        results.append(result)

        if result["status"] == "ok":
            mode = "initial backfill" if result.get("backfill") else "incremental"
            print(f"  OK · {mode}")

            if result.get("stdout"):
                print(f"  {result['stdout']}")

        elif result["status"] == "missing":
            print("  MISSING collector")

        elif result["status"] == "timeout":
            print("  TIMEOUT")

        else:
            print(
                f"  FAILED · returncode={result.get('returncode')}"
            )

            if result.get("stderr"):
                print(f"  {result['stderr']}")

        print()

    ok = [r for r in results if r["status"] == "ok"]
    failed = [r for r in results if r["status"] != "ok"]

    print("=" * 64)
    print("STATE NEWS COLLECTION COMPLETE")
    print("=" * 64)
    print()
    print(f"Collectors run: {len(results)}")
    print(f"Successful:     {len(ok)}")
    print(f"Failed:         {len(failed)}")
    print()

    if failed:
        print("Failed states:")
        for result in failed:
            print(f"  {result['state']} · {result['status']}")
        print()

    # The global builder already consumes every state's *_news.db.
    # Do not rebuild global-news.json here; that remains the responsibility
    # of build_global_news.py.
    print("State databases updated.")
    print("Existing global builder will consume these databases.")
    print()

    return 0 if not failed else 1


if __name__ == "__main__":
    raise SystemExit(main())